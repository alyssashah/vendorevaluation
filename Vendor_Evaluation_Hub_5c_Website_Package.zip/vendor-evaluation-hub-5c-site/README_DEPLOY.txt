Vendor Evaluation Hub 5c Website Package

This package contains the original 5c HTML website as index.html.

To make this open as a full website instead of a SharePoint download/preview:
1. Use index.html as the website homepage.
2. Upload this folder/package to a static website host, such as Azure Static Web Apps or an approved internal web server.
3. Share the hosted website URL with users.
4. Add the hosted website URL to SharePoint as a Quick Link or embed it in a SharePoint page if your site owner allows the domain.

Files:
- index.html: the Vendor Evaluation Hub 5c website

Important:
Uploading index.html to a SharePoint document library alone may still make it behave like a file. A full website experience requires static web hosting.
